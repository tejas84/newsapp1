import React, { Component } from 'react'
import NewsItem from './NewsItem'
import Spinner from './Spinner';
import PropTypes from 'prop-types'


export class News extends Component {
    static defaultProps = {
        country: 'in',
        pageSize: 8, 
        category: 'general',
        searchDate: '', 

      }

      static propTypes = {
        country: PropTypes.string,
        pageSize: PropTypes.number, 
        category: PropTypes.string,
        searchDate:PropTypes.number 

      }

    constructor(){
        super();
        this.state = {
            articles: [],
            loading: false,
            page:1,
            searchDate: '', 

        }
    }

    async componentDidMount(){ 
        let url = `https://newsapi.org/v2/top-headlines?country=${this.props.country}&category=${this.props.category}&apiKey=469b634787d54eb3a5ce32890fb07a33&page=1&pageSize=${this.props.pageSize}`;
        this.setState({loading: true});
        let data = await fetch(url);
        let parsedData = await data.json()
        console.log(parsedData); 
        this.setState({articles: parsedData.articles,
            totalResults: parsedData.totalResults,
            loading: false})
    }

     handlePrevClick = async ()=>{
        console.log("Previous");
        let url = `https://newsapi.org/v2/top-headlines?country=${this.props.country}&category=${this.props.category}&apiKey=469b634787d54eb3a5ce32890fb07a33&page=${this.state.page - 1}&pageSize=${this.props.pageSize}`;
        this.setState({loading: true});
        let data = await fetch(url);
        let parsedData = await data.json()
        console.log(parsedData);  
        this.setState({
            page: this.state.page - 1,
            articles: parsedData.articles,
            loading: false
        })

    }
    
     handleNextClick = async ()=>{
        console.log("Next"); 
        if (!(this.state.page + 1 > Math.ceil(this.state.totalResults/this.props.pageSize))){
            let url = `https://newsapi.org/v2/top-headlines?country=${this.props.country}&category=${this.props.category}&apiKey=469b634787d54eb3a5ce32890fb07a33&page=${this.state.page + 1}&pageSize=${this.props.pageSize}`;
            this.setState({loading: true});
            let data = await fetch(url);
            let parsedData = await data.json() 
            this.setState({
                page: this.state.page + 1,
                articles: parsedData.articles,
                loading: false
            })
    }
        }
        handleDateSearch = async () => {
          if (this.state.searchDate) {
            const fromDate = new Date(this.state.searchDate);
            const toDate = new Date(this.state.searchDate);
            toDate.setDate(toDate.getDate() + 1);
        
            const formattedFromDate = fromDate.toISOString().split('T')[0];
            const formattedToDate = toDate.toISOString().split('T')[0];
        
            const url = `https://newsapi.org/v2/everything?q=everything&apiKey=469b634787d54eb3a5ce32890fb07a33&page=1&pageSize=${this.props.pageSize}&from=${formattedFromDate}&to=${formattedToDate}`;
        
            this.setState({ loading: true });
        
            try {
              const data = await fetch(url);
              const parsedData = await data.json();
        
              console.log(parsedData); // Log the response
        
              if (parsedData.articles) {
                this.setState({
                  articles: parsedData.articles,
                  totalResults: parsedData.totalResults,
                  loading: false,
                });
              } else {
                console.error('No articles found in the API response.');
                this.setState({ loading: false });
              }
            } catch (error) {
              console.error('Error fetching news:', error);
              this.setState({ loading: false });
            }
          }
        };
        
        
        


        
          
          
          
        

    render() { 
        return (
            
            <div className="container my-3">
                <h1 className="text-center" style={{margin: '35px 0px'}}>NewsMonkey - Top Headlines</h1>
                {this.state.loading && <Spinner/>}
                <div className="row"> 
                {!this.state.loading && this.state.articles.map((element)=>{
                    return <div className="col-md-4" key={element.url}>
                        <NewsItem title={element.title?element.title:""} description={element.description?element.description:""} imageUrl={element.urlToImage} newsUrl={element.url} author={element.author} date={element.publishedAt} source={element.source.name}/>
                    </div> 
                })} 
                </div> 
                <div className="container d-flex justify-content-between">
                <button disabled={this.state.page<=1} type="button" className="btn btn-dark" onClick={this.handlePrevClick}> &larr; Previous</button>
                <button disabled={this.state.page + 1 > Math.ceil(this.state.totalResults/this.props.pageSize)} type="button" className="btn btn-dark" onClick={this.handleNextClick}>Next &rarr;</button>
                </div>

                <div className="container">
          <div className="input-group mb-3">
            <input
              type="date"
              className="form-control"
              value={this.state.searchDate}
              onChange={(e) => this.setState({ searchDate: e.target.value })}
            />
            <button
              className="btn btn-dark"
              type="button"
              onClick={this.handleDateSearch}
            >
              Search by Date
            </button>
          </div>
        </div>

            </div>
        )
    }
}

export default News
